"""
LangGraph Supervisor Agent for Financial Mentor.
Orchestrates different financial advice tools and workflows.
"""
from typing import TypedDict, Annotated, List, Dict, Any
from langgraph.graph import StateGraph, END
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage, AIMessage, SystemMessage
from config import config
from tools.finance_tools import get_all_tools
from rag.vectorstore import vector_store


# =====================
# STATE DEFINITION
# =====================

class AgentState(TypedDict):
    """State passed between nodes in the graph."""
    messages: List[Any]
    user_id: str
    user_profile: Dict
    context: List[str]  # RAG context
    tool_results: Dict
    response: str
    suggestions: List[str]


# =====================
# AGENT NODES
# =====================

def initialize_node(state: AgentState) -> AgentState:
    """Initialize the conversation with user context."""
    state["context"] = []
    state["tool_results"] = {}
    state["suggestions"] = []
    return state


def rag_retrieval_node(state: AgentState) -> AgentState:
    """Retrieve relevant financial knowledge."""
    # Get the last user message
    last_message = state["messages"][-1]
    if isinstance(last_message, HumanMessage):
        query = last_message.content
        
        # Search for relevant documents
        try:
            results = vector_store.search(query, limit=3)
            state["context"] = [doc["content"] for doc in results]
        except Exception:
            state["context"] = []
    
    return state


def tool_router_node(state: AgentState) -> AgentState:
    """Decide which tools to use based on user query."""
    last_message = state["messages"][-1]
    if not isinstance(last_message, HumanMessage):
        return state
    
    query = last_message.content.lower()
    
    # Simple keyword-based routing
    tool_results = {}
    
    if any(word in query for word in ["mutual fund", "mf", "nav", "fund"]):
        from tools.finance_tools import get_popular_funds
        tool_results["popular_funds"] = get_popular_funds.invoke("")
    
    if any(word in query for word in ["dollar", "usd", "forex", "currency"]):
        from tools.finance_tools import get_usd_inr_rate
        tool_results["usd_rate"] = get_usd_inr_rate.invoke("")
    
    state["tool_results"] = tool_results
    return state


def response_generator_node(state: AgentState) -> AgentState:
    """Generate the final response using LLM."""
    
    llm = ChatOpenAI(
        model=config.LLM_MODEL,
        openai_api_key=config.OPENAI_API_KEY,
        temperature=0.7
    )
    
    # Build system prompt
    system_prompt = """You are a helpful financial mentor for Indian gig workers.
    
Your role:
- Give simple, actionable financial advice in a friendly tone
- Focus on practical tips for people with variable income
- Recommend suitable Indian investment options
- Use ₹ for currency and Indian financial terms
- Keep responses concise and easy to understand

User Profile:
{profile}

Relevant Knowledge:
{context}

Tool Results:
{tools}

Provide helpful, personalized advice based on the above context."""

    # Format context
    profile_str = str(state.get("user_profile", {}))
    context_str = "\n".join(state.get("context", []))
    tools_str = str(state.get("tool_results", {}))
    
    formatted_prompt = system_prompt.format(
        profile=profile_str,
        context=context_str,
        tools=tools_str
    )
    
    # Build messages
    messages = [SystemMessage(content=formatted_prompt)]
    messages.extend(state["messages"])
    
    # Generate response
    response = llm.invoke(messages)
    state["response"] = response.content
    
    # Add suggestions
    state["suggestions"] = [
        "💰 Calculate SIP returns",
        "📊 View my cashflow",
        "📈 Show popular mutual funds"
    ]
    
    return state


# =====================
# GRAPH BUILDER
# =====================

def create_financial_mentor_graph() -> StateGraph:
    """Create the LangGraph StateGraph for financial mentor."""
    
    # Initialize graph with state type
    graph = StateGraph(AgentState)
    
    # Add nodes
    graph.add_node("initialize", initialize_node)
    graph.add_node("rag_retrieval", rag_retrieval_node)
    graph.add_node("tool_router", tool_router_node)
    graph.add_node("response_generator", response_generator_node)
    
    # Define edges (flow)
    graph.set_entry_point("initialize")
    graph.add_edge("initialize", "rag_retrieval")
    graph.add_edge("rag_retrieval", "tool_router")
    graph.add_edge("tool_router", "response_generator")
    graph.add_edge("response_generator", END)
    
    return graph.compile()


# Create compiled graph instance
mentor_agent = create_financial_mentor_graph()


# =====================
# HELPER FUNCTION
# =====================

def chat_with_mentor(
    user_id: str,
    message: str,
    user_profile: Dict = None
) -> Dict:
    """
    Process a chat message through the financial mentor agent.
    
    Args:
        user_id: User identifier
        message: User's message
        user_profile: Optional user profile data
    
    Returns:
        Response with suggestions
    """
    # Prepare initial state
    initial_state = {
        "messages": [HumanMessage(content=message)],
        "user_id": user_id,
        "user_profile": user_profile or {},
        "context": [],
        "tool_results": {},
        "response": "",
        "suggestions": []
    }
    
    # Run the graph
    result = mentor_agent.invoke(initial_state)
    
    return {
        "response": result["response"],
        "suggestions": result["suggestions"]
    }