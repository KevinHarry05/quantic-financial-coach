"""
Pydantic schemas for request/response validation.
Simple models for Indian gig worker financial data.
"""
from pydantic import BaseModel, Field
from typing import Optional, Dict, List
from datetime import datetime


# =====================
# USER PROFILE SCHEMAS
# =====================

class ProfileCreate(BaseModel):
    """Schema for creating a new profile."""
    user_id: str
    name: str
    monthly_income: float = 0
    income_type: str = "variable"  # fixed, variable, mixed
    expenses: Dict[str, float] = {}
    savings_goal: float = 0
    risk_tolerance: str = "moderate"  # low, moderate, high


class ProfileResponse(BaseModel):
    """Schema for profile response."""
    id: str
    user_id: str
    name: str
    monthly_income: float
    income_type: str
    expenses: Dict[str, float]
    savings_goal: float
    risk_tolerance: str


# =====================
# CHAT SCHEMAS
# =====================

class ChatRequest(BaseModel):
    """Schema for chat requests."""
    user_id: str
    message: str
    context: Optional[Dict] = None


class ChatResponse(BaseModel):
    """Schema for chat responses."""
    response: str
    suggestions: List[str] = []
    actions: List[Dict] = []


# =====================
# SIMULATION SCHEMAS
# =====================

class CashflowRequest(BaseModel):
    """Schema for cashflow simulation."""
    user_id: str
    months: int = 6
    income_variation: float = 0.2  # 20% variation typical for gig work


class CashflowResponse(BaseModel):
    """Schema for cashflow simulation response."""
    projections: List[Dict]
    total_savings: float
    risk_months: List[int]  # Months where expenses > income
    recommendations: List[str]


class SIPRequest(BaseModel):
    """Schema for SIP calculation."""
    monthly_amount: float
    years: int = 5
    expected_return: float = 12.0  # % annual


class SIPResponse(BaseModel):
    """Schema for SIP calculation response."""
    total_invested: float
    expected_value: float
    wealth_gain: float
    monthly_breakdown: List[Dict]