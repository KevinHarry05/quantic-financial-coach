-- =====================
-- DROP EXISTING TABLES (if any)
-- =====================
DROP TABLE IF EXISTS conversations CASCADE;
DROP TABLE IF EXISTS market_cache CASCADE;
DROP TABLE IF EXISTS finance_docs CASCADE;
DROP TABLE IF EXISTS profiles CASCADE;

-- Drop existing function
DROP FUNCTION IF EXISTS match_docs;

-- =====================
-- ENABLE EXTENSIONS
-- =====================
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =====================
-- PROFILES TABLE
-- =====================
CREATE TABLE profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    
    -- Segmentation
    segment TEXT DEFAULT 'new_user',
    risk_level TEXT DEFAULT 'moderate',
    
    -- Income as JSONB
    income_range JSONB DEFAULT '{
        "min": 0,
        "max": 0,
        "average": 0,
        "sources": []
    }'::jsonb,
    
    -- Expenses breakdown
    expenses JSONB DEFAULT '{}'::jsonb,
    savings_goal DECIMAL(12,2) DEFAULT 0,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================
-- CONVERSATIONS TABLE
-- =====================
CREATE TABLE conversations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    profile_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    messages JSONB[] DEFAULT ARRAY[]::jsonb[],
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================
-- MARKET CACHE TABLE
-- =====================
CREATE TABLE market_cache (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    symbol TEXT NOT NULL,
    source TEXT NOT NULL,
    data JSONB NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ DEFAULT NOW() + INTERVAL '1 hour',
    UNIQUE(symbol, source)
);

-- =====================
-- FINANCE DOCS (RAG)
-- =====================
CREATE TABLE finance_docs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    category TEXT NOT NULL,
    embedding VECTOR(1536),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vector similarity index
CREATE INDEX ON finance_docs USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- =====================
-- SIMILARITY SEARCH FUNCTION
-- =====================
CREATE OR REPLACE FUNCTION match_docs(
    query_embedding VECTOR(1536),
    match_count INT DEFAULT 3,
    match_threshold FLOAT DEFAULT 0.5
)
RETURNS TABLE (
    id UUID,
    title TEXT,
    content TEXT,
    category TEXT,
    similarity FLOAT
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT
        finance_docs.id,
        finance_docs.title,
        finance_docs.content,
        finance_docs.category,
        1 - (finance_docs.embedding <=> query_embedding) AS similarity
    FROM finance_docs
    WHERE 1 - (finance_docs.embedding <=> query_embedding) > match_threshold
    ORDER BY finance_docs.embedding <=> query_embedding
    LIMIT match_count;
END;
$$;

-- =====================
-- INDEXES
-- =====================
CREATE INDEX idx_profiles_user ON profiles(user_id);
CREATE INDEX idx_conversations_profile ON conversations(profile_id);
CREATE INDEX idx_cache_symbol ON market_cache(symbol);