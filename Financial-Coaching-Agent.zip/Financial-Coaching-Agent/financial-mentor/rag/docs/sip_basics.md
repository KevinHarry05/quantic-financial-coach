# SIP Basics for Beginners

Category: investment

---

## What is SIP?

SIP = Fixed amount invested monthly in mutual funds automatically.

## Why SIP Works

- **Rupee cost averaging**: Buy more units when market is low
- **Discipline**: Auto-debit removes emotion
- **Compounding**: ₹5000/month for 20 years = ₹50+ lakh

## Quick Start

| Step | Action |
|------|--------|
| 1 | Download Groww/Kuvera app |
| 2 | Complete KYC (10 min) |
| 3 | Choose Nifty 50 Index Fund |
| 4 | Set ₹1000 monthly SIP |
| 5 | Forget for 5+ years |

## For Variable Income

- Start with amount you can ALWAYS afford
- Top-up in good months
- Never stop SIP when market falls

## Recommended Funds

- **Beginners**: UTI Nifty 50 Index
- **Tax saving**: Mirae Asset ELSS  
- **Flexible**: Parag Parikh Flexi Cap