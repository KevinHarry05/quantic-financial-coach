# Emergency Fund for Gig Workers

Category: savings

---

## How Much to Save

**Formula**: (Monthly Expenses × 6) + (Average Income × 3)

**Example**: 
- Expenses: ₹30,000/month
- Target: ₹1,80,000 minimum

## Where to Keep It

| Portion | Where | Why |
|---------|-------|-----|
| 25% | Savings Account | Instant access |
| 50% | Liquid Fund | Better returns (6-7%) |
| 25% | FD | Slightly higher returns |

## Building It

1. Save 20% of every payment received
2. Automate transfer to separate account
3. Takes 6-12 months to build fully

## Use ONLY For

✅ Job loss / no work for weeks
✅ Medical emergencies  
✅ Urgent repairs

## Never Use For

❌ Shopping or gadgets
❌ Vacations
❌ "Good deals"