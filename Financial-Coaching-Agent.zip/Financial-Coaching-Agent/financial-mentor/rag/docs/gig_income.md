# Managing Gig Income in India

Category: budgeting

---

## The Variable Income Challenge

Gig workers face unpredictable monthly income. Here's how to manage it:

## Modified 50-30-20 Rule

Based on your LOWEST earning month:
- **50% Needs**: Rent, food, utilities
- **30% Buffer**: Save for low months  
- **20% Goals**: SIP, savings

## Income Smoothing

1. Calculate 6-month average income
2. Pay yourself fixed "salary" from average
3. Bank surplus in good months
4. Draw from surplus in bad months

## 3-Account System

| Account | Purpose |
|---------|---------|
| Income | All gig payments land here |
| Expense | Fixed monthly transfer |
| Savings | Surplus + investments |

## Golden Rule

Save 20% of EVERY payment before spending anything.