"""
Simple RAG vectorstore with Supabase PGVector.
Auto-indexes 5 Indian finance docs on startup.
"""
from pathlib import Path
from typing import List, Dict
from supabase import create_client
from langchain_openai import OpenAIEmbeddings
from langchain.tools import tool
from config import config


class VectorStore:
    """Simple vector store for finance knowledge."""
    
    def __init__(self):
        self.supabase = create_client(config.SUPABASE_URL, config.SUPABASE_KEY)
        self.embeddings = OpenAIEmbeddings(
            model="text-embedding-3-small",
            openai_api_key=config.OPENAI_API_KEY
        )
        self.docs_path = Path(__file__).parent / "docs"
    
    def add_doc(self, title: str, content: str, category: str) -> str:
        """Add document with embedding."""
        embedding = self.embeddings.embed_query(content)
        result = self.supabase.table("finance_docs").insert({
            "title": title,
            "content": content,
            "category": category,
            "embedding": embedding
        }).execute()
        return result.data[0]["id"]
    
    def search(self, query: str, limit: int = 3) -> List[Dict]:
        """Search similar documents."""
        query_embedding = self.embeddings.embed_query(query)
        result = self.supabase.rpc("match_docs", {
            "query_embedding": query_embedding,
            "match_count": limit,
            "match_threshold": 0.4
        }).execute()
        return result.data
    
    def count_docs(self) -> int:
        """Get document count."""
        result = self.supabase.table("finance_docs").select("id", count="exact").execute()
        return result.count or 0
    
    def load_markdown_files(self) -> int:
        """Load .md files from docs folder."""
        count = 0
        if not self.docs_path.exists():
            return 0
        
        for md_file in self.docs_path.glob("*.md"):
            content = md_file.read_text(encoding="utf-8")
            lines = content.strip().split("\n")
            
            # Extract title from first heading
            title = md_file.stem.replace("_", " ").title()
            category = "general"
            
            for line in lines[:5]:
                if line.startswith("# "):
                    title = line[2:].strip()
                elif line.startswith("Category:"):
                    category = line.split(":")[1].strip().lower()
            
            self.add_doc(title, content, category)
            count += 1
            print(f"  ✓ {title}")
        
        return count
    
    def seed_docs(self) -> int:
        """Seed 5 core Indian finance documents."""
        docs = [
            {
                "title": "SIP Basics for Beginners",
                "category": "investment",
                "content": """
SIP (Systematic Investment Plan) lets you invest fixed amounts monthly in mutual funds.

Key Points:
• Start with just ₹500/month
• Rupee cost averaging reduces risk
• Auto-debit ensures discipline
• No need to time the market

Best for gig workers:
• Start small, increase when income is good
• Use flexi-SIP for variable income
• Index funds have lowest costs (0.1%)

Popular funds: Nifty 50 Index, ELSS for tax saving
Returns: 12-15% long-term average
"""
            },
            {
                "title": "PPF - Public Provident Fund",
                "category": "savings",
                "content": """
PPF is a government savings scheme with guaranteed 7.1% returns.

Features:
• Min ₹500/year, Max ₹1.5 lakh/year
• 15-year lock-in (partial withdrawal after 7 years)
• Tax-free: Investment, Interest, and Maturity (EEE)

Why good for gig workers:
• Zero risk, government guaranteed
• Forces long-term savings habit
• ₹1.5 lakh gives full 80C tax benefit

Open at: Any bank or post office
Pro tip: Invest before 5th of month for that month's interest
"""
            },
            {
                "title": "Emergency Fund Guide",
                "category": "savings",
                "content": """
Emergency fund = 6 months expenses saved for unexpected situations.

For gig workers (variable income):
• Target: 6 months expenses + 3 months income
• Example: ₹30k expenses → Need ₹1.8-3 lakh saved

Where to keep:
• 25% in savings account (instant access)
• 50% in liquid fund (6-7% returns, 1-day withdrawal)
• 25% in short-term FD

Building strategy:
• Save 20% of every payment received
• Automate transfers on payday
• Don't touch for non-emergencies

Use only for: Job loss, medical emergency, urgent repairs
"""
            },
            {
                "title": "Tax Guide for Freelancers",
                "category": "tax",
                "content": """
Gig workers are self-employed and must handle their own taxes.

Key deductions (Old Regime):
• 80C: ₹1.5 lakh (PPF, ELSS, LIC)
• 80D: ₹25,000 (health insurance)
• 80CCD: ₹50,000 extra (NPS)

Business expenses you can claim:
• Internet, phone bills
• Laptop/computer (depreciation)
• Software subscriptions
• Co-working space

Important:
• Pay advance tax if liability > ₹10,000
• Due dates: 15 Jun, 15 Sep, 15 Dec, 15 Mar
• Keep records for 6 years
• GST registration if turnover > ₹20 lakh
"""
            },
            {
                "title": "NPS for Retirement",
                "category": "retirement",
                "content": """
NPS (National Pension System) is a retirement savings scheme.

Key benefits:
• Extra ₹50,000 tax deduction (above 80C limit)
• Low fund management cost (0.01%)
• Market-linked returns (10-12% historically)

How it works:
• Choose equity/debt allocation
• Invest regularly till age 60
• At 60: 60% lump sum (tax-free), 40% pension

For gig workers:
• No employer contribution, so save more
• Use aggressive equity allocation when young
• ₹5000/month from age 25 = ₹1.5+ crore at 60

Open eNPS account online in 10 minutes.
"""
            }
        ]
        
        count = 0
        for doc in docs:
            try:
                self.add_doc(doc["title"], doc["content"], doc["category"])
                count += 1
                print(f"  ✓ {doc['title']}")
            except Exception as e:
                print(f"  ✗ {doc['title']}: {e}")
        
        return count


# Global instance
_store = None

def get_store() -> VectorStore:
    global _store
    if _store is None:
        _store = VectorStore()
    return _store


# =====================
# LANGCHAIN TOOL
# =====================

@tool
def search_finance_concepts(query: str) -> str:
    """
    Search Indian finance knowledge base.
    
    Use for questions about: SIP, mutual funds, PPF, tax saving,
    emergency funds, insurance, retirement planning, GST.
    
    Args:
        query: User's finance question
    
    Returns:
        Relevant financial knowledge
    """
    store = get_store()
    results = store.search(query, limit=3)
    
    if not results:
        return "No specific info found. Provide general guidance."
    
    output = []
    for doc in results:
        output.append(f"### {doc['title']}\n{doc['content'][:400]}...")
    
    return "\n---\n".join(output)


# =====================
# STARTUP FUNCTION
# =====================

def init_knowledge_base(force: bool = False) -> int:
    """Initialize KB on startup. Only seeds if empty."""
    print("\n📚 Initializing Knowledge Base...")
    
    store = get_store()
    count = store.count_docs()
    
    if count > 0 and not force:
        print(f"✅ Already has {count} docs. Skipping.\n")
        return count
    
    print("Seeding documents...")
    seeded = store.seed_docs()
    
    print("Loading markdown files...")
    loaded = store.load_markdown_files()
    
    total = seeded + loaded
    print(f"✅ Indexed {total} documents.\n")
    return total