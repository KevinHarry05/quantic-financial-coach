"""
SIP (Systematic Investment Plan) calculator.
Helps gig workers understand long-term wealth creation.
"""
from typing import Dict, List


def calculate_sip(
    monthly_amount: float,
    years: int = 5,
    expected_return: float = 12.0
) -> Dict:
    """
    Calculate SIP returns using compound interest.
    
    Args:
        monthly_amount: Monthly SIP amount in INR
        years: Investment period in years
        expected_return: Expected annual return percentage
    
    Returns:
        SIP calculation results with monthly breakdown
    """
    # Convert annual return to monthly
    monthly_rate = expected_return / 12 / 100
    total_months = years * 12
    
    # SIP formula: M × ({[1 + r]^n - 1} / r) × (1 + r)
    if monthly_rate > 0:
        future_value = monthly_amount * (
            ((1 + monthly_rate) ** total_months - 1) / monthly_rate
        ) * (1 + monthly_rate)
    else:
        future_value = monthly_amount * total_months
    
    total_invested = monthly_amount * total_months
    wealth_gain = future_value - total_invested
    
    # Generate yearly breakdown
    monthly_breakdown = generate_yearly_breakdown(
        monthly_amount, years, expected_return
    )
    
    return {
        "monthly_sip": round(monthly_amount, 2),
        "years": years,
        "expected_return": expected_return,
        "total_invested": round(total_invested, 2),
        "expected_value": round(future_value, 2),
        "wealth_gain": round(wealth_gain, 2),
        "wealth_gain_percent": round((wealth_gain / total_invested) * 100, 2),
        "monthly_breakdown": monthly_breakdown
    }


def generate_yearly_breakdown(
    monthly_amount: float,
    years: int,
    annual_return: float
) -> List[Dict]:
    """Generate year-by-year breakdown of SIP growth."""
    
    monthly_rate = annual_return / 12 / 100
    breakdown = []
    
    for year in range(1, years + 1):
        months = year * 12
        
        if monthly_rate > 0:
            value = monthly_amount * (
                ((1 + monthly_rate) ** months - 1) / monthly_rate
            ) * (1 + monthly_rate)
        else:
            value = monthly_amount * months
        
        invested = monthly_amount * months
        
        breakdown.append({
            "year": year,
            "invested": round(invested, 2),
            "value": round(value, 2),
            "gain": round(value - invested, 2)
        })
    
    return breakdown


def suggest_sip_for_goal(
    goal_amount: float,
    years: int = 5,
    expected_return: float = 12.0
) -> Dict:
    """
    Calculate required SIP for a financial goal.
    
    Args:
        goal_amount: Target amount in INR
        years: Time to achieve goal
        expected_return: Expected annual return
    
    Returns:
        Required monthly SIP and plan details
    """
    monthly_rate = expected_return / 12 / 100
    total_months = years * 12
    
    # Reverse SIP formula to find monthly amount
    if monthly_rate > 0:
        monthly_sip = goal_amount / (
            ((1 + monthly_rate) ** total_months - 1) / monthly_rate
        ) / (1 + monthly_rate)
    else:
        monthly_sip = goal_amount / total_months
    
    return {
        "goal_amount": round(goal_amount, 2),
        "years": years,
        "required_monthly_sip": round(monthly_sip, 2),
        "expected_return": expected_return,
        "total_investment_needed": round(monthly_sip * total_months, 2)
    }