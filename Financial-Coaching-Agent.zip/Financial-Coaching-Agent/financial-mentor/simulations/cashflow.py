"""
Cashflow simulation for gig workers.
Handles variable income patterns typical in gig economy.
"""
import random
from typing import Dict, List
from datetime import datetime, timedelta


def simulate_cashflow(
    monthly_income: float,
    expenses: Dict[str, float],
    months: int = 6,
    income_variation: float = 0.2,
    savings_goal: float = 0
) -> Dict:
    """
    Simulate cashflow for gig worker with variable income.
    
    Args:
        monthly_income: Average monthly income
        expenses: Dict of expense categories and amounts
        months: Number of months to simulate
        income_variation: Income variation factor (0.2 = ±20%)
        savings_goal: Target monthly savings
    
    Returns:
        Cashflow projections and recommendations
    """
    total_expenses = sum(expenses.values())
    projections = []
    risk_months = []
    cumulative_savings = 0
    
    for month in range(1, months + 1):
        # Simulate variable income
        variation = random.uniform(-income_variation, income_variation)
        actual_income = monthly_income * (1 + variation)
        
        # Calculate savings
        savings = actual_income - total_expenses
        cumulative_savings += max(savings, 0)
        
        # Check if month is at risk
        is_risk = savings < 0
        if is_risk:
            risk_months.append(month)
        
        projections.append({
            "month": month,
            "income": round(actual_income, 2),
            "expenses": round(total_expenses, 2),
            "savings": round(savings, 2),
            "cumulative_savings": round(cumulative_savings, 2),
            "is_risk": is_risk
        })
    
    # Generate recommendations
    recommendations = generate_recommendations(
        projections, risk_months, monthly_income, 
        total_expenses, savings_goal
    )
    
    return {
        "projections": projections,
        "total_savings": round(cumulative_savings, 2),
        "risk_months": risk_months,
        "recommendations": recommendations
    }


def generate_recommendations(
    projections: List[Dict],
    risk_months: List[int],
    income: float,
    expenses: float,
    savings_goal: float
) -> List[str]:
    """Generate personalized recommendations based on cashflow."""
    
    recommendations = []
    
    # Check risk frequency
    risk_ratio = len(risk_months) / len(projections)
    
    if risk_ratio > 0.3:
        recommendations.append(
            "⚠️ High income variability detected. "
            "Build an emergency fund of 3-6 months expenses first."
        )
    
    # Check savings vs goal
    avg_savings = sum(p["savings"] for p in projections) / len(projections)
    
    if savings_goal > 0 and avg_savings < savings_goal:
        gap = savings_goal - avg_savings
        recommendations.append(
            f"📊 You're ₹{gap:.0f}/month short of your goal. "
            "Consider reducing discretionary spending."
        )
    
    # Emergency fund recommendation
    emergency_fund = expenses * 3
    recommendations.append(
        f"🏦 Target emergency fund: ₹{emergency_fund:,.0f} "
        f"(3 months of expenses)"
    )
    
    # SIP recommendation for gig workers
    if avg_savings > 0:
        sip_amount = avg_savings * 0.5
        recommendations.append(
            f"💰 Consider starting a SIP of ₹{sip_amount:,.0f}/month "
            "in a liquid fund for flexibility."
        )
    
    return recommendations