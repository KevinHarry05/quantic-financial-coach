"""
Test script for Financial Mentor API.
Run after starting Flask server: python app.py
"""
import requests
import json

BASE = "http://localhost:5000"

def test(name, method, endpoint, data=None, show_full=False):
    """Generic test helper."""
    print(f"\n{'='*50}")
    print(f"🧪 {name}")
    print(f"{'='*50}")
    
    try:
        if method == "GET":
            r = requests.get(f"{BASE}{endpoint}", timeout=30)
        else:
            r = requests.post(f"{BASE}{endpoint}", json=data, timeout=30)
        
        result = r.json()
        status = "✅" if r.status_code in [200, 201] else "❌"
        print(f"{status} Status: {r.status_code}")
        
        if show_full:
            print(json.dumps(result, indent=2)[:500])
        else:
            # Show key info only
            for key in ["response", "total_savings", "expected_value", "profile", "funds"]:
                if key in result:
                    val = result[key]
                    if isinstance(val, str) and len(val) > 200:
                        val = val[:200] + "..."
                    print(f"📌 {key}: {val}")
        
        return r.status_code in [200, 201]
    
    except requests.exceptions.ConnectionError:
        print("❌ Server not running! Start with: python app.py")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False


def main():
    print("\n" + "🚀 FINANCIAL MENTOR API TESTS ".center(50, "="))
    
    results = []
    
    # 1. Health Check
    results.append(("Health", test(
        "Health Check", "GET", "/"
    )))
    
    # 2. Create Profile
    results.append(("Profile Create", test(
        "Create Profile", "POST", "/profile",
        {
            "user_id": "test_gig_worker",
            "name": "Priya Sharma",
            "monthly_income": 35000,
            "income_type": "variable",
            "expenses": {"rent": 10000, "food": 6000, "transport": 2000},
            "savings_goal": 8000,
            "risk_tolerance": "moderate"
        }
    )))
    
    # 3. Get Profile
    results.append(("Profile Get", test(
        "Get Profile", "GET", "/profile/test_gig_worker"
    )))
    
    # 4. Chat
    results.append(("Chat", test(
        "Chat with Mentor", "POST", "/chat",
        {
            "user_id": "test_gig_worker",
            "message": "I earn variable income as a delivery partner. How should I save?"
        },
        show_full=True
    )))
    
    # 5. Cashflow Simulation
    results.append(("Cashflow", test(
        "Cashflow Simulation", "POST", "/simulate/cashflow",
        {"user_id": "test_gig_worker", "months": 6}
    )))
    
    # 6. SIP Calculator
    results.append(("SIP", test(
        "SIP Calculator", "POST", "/simulate/sip",
        {"monthly_amount": 3000, "years": 10, "expected_return": 12}
    )))
    
    # 7. Goal Calculator
    results.append(("Goal", test(
        "Goal Calculator", "POST", "/simulate/goal",
        {"goal_amount": 500000, "years": 5}
    )))
    
    # 8. Popular Funds
    results.append(("Funds", test(
        "Popular Mutual Funds", "GET", "/market/funds/popular"
    )))
    
    # 9. Search Funds
    results.append(("Search", test(
        "Search Funds", "GET", "/market/funds/search?q=axis"
    )))
    
    # 10. USD Rate
    results.append(("USD/INR", test(
        "USD to INR Rate", "GET", "/market/currency/usd-inr"
    )))
    
    # Summary
    print("\n" + " TEST SUMMARY ".center(50, "="))
    passed = 0
    for name, success in results:
        icon = "✅" if success else "❌"
        print(f"  {icon} {name}")
        if success:
            passed += 1
    
    print(f"\n📊 Result: {passed}/{len(results)} passed")
    print("=" * 50)
    
    return passed == len(results)


if __name__ == "__main__":
    import sys
    success = main()
    sys.exit(0 if success else 1)