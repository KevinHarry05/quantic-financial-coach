"""
Financial tools for fetching market data.
Uses MFapi.in for Indian mutual funds and Alpha Vantage for stocks.
"""
import requests
from typing import Optional, Dict, List
from datetime import datetime, timedelta
from langchain.tools import tool
from config import config


# =====================
# MFapi.in TOOLS (Indian Mutual Funds)
# =====================

@tool
def get_mutual_fund_nav(scheme_code: str) -> Dict:
    """
    Get latest NAV for an Indian mutual fund.
    
    Args:
        scheme_code: AMFI scheme code (e.g., '119551' for SBI Bluechip)
    
    Returns:
        Fund details with current NAV
    """
    try:
        url = f"https://api.mfapi.in/mf/{scheme_code}"
        response = requests.get(url, timeout=10)
        data = response.json()
        
        return {
            "scheme_name": data.get("meta", {}).get("scheme_name"),
            "nav": data.get("data", [{}])[0].get("nav"),
            "date": data.get("data", [{}])[0].get("date"),
            "fund_house": data.get("meta", {}).get("fund_house")
        }
    except Exception as e:
        return {"error": str(e)}


@tool
def search_mutual_funds(query: str) -> List[Dict]:
    """
    Search for Indian mutual funds by name.
    
    Args:
        query: Search term (e.g., 'SBI', 'HDFC', 'index')
    
    Returns:
        List of matching funds with scheme codes
    """
    try:
        url = "https://api.mfapi.in/mf/search"
        params = {"q": query}
        response = requests.get(url, params=params, timeout=10)
        funds = response.json()
        
        # Return top 5 results
        return [
            {"scheme_code": f["schemeCode"], "scheme_name": f["schemeName"]}
            for f in funds[:5]
        ]
    except Exception as e:
        return [{"error": str(e)}]


@tool
def get_popular_funds() -> List[Dict]:
    """
    Get list of popular mutual funds for beginners.
    Pre-curated list good for gig workers starting their investment journey.
    
    Returns:
        List of recommended funds with details
    """
    popular_schemes = [
        {"code": "119551", "name": "SBI Bluechip Fund", "type": "Large Cap"},
        {"code": "120503", "name": "Axis Long Term Equity", "type": "ELSS Tax Saver"},
        {"code": "118989", "name": "HDFC Index Sensex", "type": "Index Fund"},
        {"code": "135781", "name": "Parag Parikh Flexi Cap", "type": "Flexi Cap"},
        {"code": "125354", "name": "Mirae Asset Large Cap", "type": "Large Cap"}
    ]
    
    results = []
    for scheme in popular_schemes:
        fund_data = get_mutual_fund_nav.invoke(scheme["code"])
        if "error" not in fund_data:
            results.append({
                **scheme,
                "nav": fund_data.get("nav"),
                "date": fund_data.get("date")
            })
    
    return results


# =====================
# ALPHA VANTAGE TOOLS (Stocks & Currency)
# =====================

@tool
def get_stock_price(symbol: str) -> Dict:
    """
    Get current stock price from Alpha Vantage.
    
    Args:
        symbol: Stock symbol (e.g., 'RELIANCE.BSE' for Indian stocks)
    
    Returns:
        Stock price details
    """
    try:
        url = "https://www.alphavantage.co/query"
        params = {
            "function": "GLOBAL_QUOTE",
            "symbol": symbol,
            "apikey": config.ALPHA_VANTAGE_KEY
        }
        response = requests.get(url, params=params, timeout=10)
        data = response.json().get("Global Quote", {})
        
        return {
            "symbol": data.get("01. symbol"),
            "price": data.get("05. price"),
            "change": data.get("09. change"),
            "change_percent": data.get("10. change percent")
        }
    except Exception as e:
        return {"error": str(e)}


@tool
def get_usd_inr_rate() -> Dict:
    """
    Get current USD to INR exchange rate.
    Useful for gig workers earning in foreign currency.
    
    Returns:
        Exchange rate details
    """
    try:
        url = "https://www.alphavantage.co/query"
        params = {
            "function": "CURRENCY_EXCHANGE_RATE",
            "from_currency": "USD",
            "to_currency": "INR",
            "apikey": config.ALPHA_VANTAGE_KEY
        }
        response = requests.get(url, params=params, timeout=10)
        data = response.json().get("Realtime Currency Exchange Rate", {})
        
        return {
            "rate": data.get("5. Exchange Rate"),
            "last_updated": data.get("6. Last Refreshed")
        }
    except Exception as e:
        return {"error": str(e)}


# =====================
# TOOL COLLECTION
# =====================

def get_all_tools():
    """Return all available finance tools."""
    return [
        get_mutual_fund_nav,
        search_mutual_funds,
        get_popular_funds,
        get_stock_price,
        get_usd_inr_rate
    ]