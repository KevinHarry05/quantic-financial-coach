"""
Configuration loader for the Financial Mentor app.
Loads environment variables and provides config access.
"""
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class Config:
    """App configuration from environment variables."""
    
    # OpenAI
    OPENAI_API_KEY = os.getenv("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")
    
    # Supabase
    SUPABASE_URL = os.getenv("https://grjbkprkqpkzogwsskdi.supabase.co")
    SUPABASE_KEY = os.getenv("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdyamJrcHJrcXBrem9nd3Nza2RpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM3MjU2MTcsImV4cCI6MjA3OTMwMTYxN30.PYWtozD7ZMwo73jUgxriPkeUSLZG-bTCJsa-jJdQJ2A")
    SUPABASE_SERVICE_KEY = os.getenv("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdyamJrcHJrcXBrem9nd3Nza2RpIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MzcyNTYxNywiZXhwIjoyMDc5MzAxNjE3fQ.q8ME3H8eRM2OQ6urrir61kiY8LzDX8DRvqRynRQn81o")
    
    # Alpha Vantage
    ALPHA_VANTAGE_KEY = os.getenv("ALPHA_VANTAGE_KEY")
    
    # Flask
    SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "dev-secret-key")
    
    # Model settings (using cheaper model for $5 budget)
    LLM_MODEL = "gpt-3.5-turbo"
    EMBEDDING_MODEL = "text-embedding-3-small"


config = Config()