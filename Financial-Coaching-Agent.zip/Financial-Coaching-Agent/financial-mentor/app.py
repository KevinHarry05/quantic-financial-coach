"""
Flask application for Financial Mentor API.
Main entry point with all routes.
"""
from flask import Flask, request, jsonify
from flask_cors import CORS
from supabase import create_client
from datetime import datetime

from config import config
from models.schemas import (
    ProfileCreate, ChatRequest, 
    CashflowRequest, SIPRequest
)
from agents.supervisor import chat_with_mentor
from simulations.cashflow import simulate_cashflow
from simulations.sip_calculator import calculate_sip, suggest_sip_for_goal

# =====================
# APP INITIALIZATION
# =====================

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend

# Initialize Supabase client
supabase = create_client(config.SUPABASE_URL, config.SUPABASE_KEY)


# =====================
# HEALTH CHECK
# =====================

@app.route("/", methods=["GET"])
def health_check():
    """Health check endpoint."""
    return jsonify({
        "status": "healthy",
        "service": "Financial Mentor API",
        "version": "1.0.0"
    })


# =====================
# PROFILE ROUTES
# =====================

@app.route("/profile", methods=["POST"])
def create_profile():
    """Create a new user profile."""
    try:
        data = request.json
        profile = ProfileCreate(**data)
        
        result = supabase.table("profiles").insert({
            "user_id": profile.user_id,
            "name": profile.name,
            "monthly_income": profile.monthly_income,
            "income_type": profile.income_type,
            "expenses": profile.expenses,
            "savings_goal": profile.savings_goal,
            "risk_tolerance": profile.risk_tolerance
        }).execute()
        
        return jsonify({
            "success": True,
            "profile": result.data[0]
        }), 201
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/profile/<user_id>", methods=["GET"])
def get_profile(user_id: str):
    """Get user profile by ID."""
    try:
        result = supabase.table("profiles")\
            .select("*")\
            .eq("user_id", user_id)\
            .single()\
            .execute()
        
        return jsonify({"profile": result.data})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 404


@app.route("/profile/<user_id>", methods=["PUT"])
def update_profile(user_id: str):
    """Update user profile."""
    try:
        data = request.json
        data["updated_at"] = datetime.utcnow().isoformat()
        
        result = supabase.table("profiles")\
            .update(data)\
            .eq("user_id", user_id)\
            .execute()
        
        return jsonify({
            "success": True,
            "profile": result.data[0]
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400


# =====================
# CHAT ROUTE
# =====================

@app.route("/chat", methods=["POST"])
def chat():
    """Chat with the financial mentor agent."""
    try:
        data = request.json
        chat_req = ChatRequest(**data)
        
        # Get user profile for context
        profile = None
        try:
            profile_result = supabase.table("profiles")\
                .select("*")\
                .eq("user_id", chat_req.user_id)\
                .single()\
                .execute()
            profile = profile_result.data
        except Exception:
            pass  # Profile not found, continue without it
        
        # Process with agent
        result = chat_with_mentor(
            user_id=chat_req.user_id,
            message=chat_req.message,
            user_profile=profile
        )
        
        # Save conversation
        supabase.table("conversations").insert([
            {
                "user_id": chat_req.user_id,
                "role": "user",
                "content": chat_req.message
            },
            {
                "user_id": chat_req.user_id,
                "role": "assistant",
                "content": result["response"]
            }
        ]).execute()
        
        return jsonify({
            "response": result["response"],
            "suggestions": result["suggestions"]
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# =====================
# SIMULATION ROUTES
# =====================

@app.route("/simulate/cashflow", methods=["POST"])
def simulate_cashflow_route():
    """Simulate cashflow for a user."""
    try:
        data = request.json
        req = CashflowRequest(**data)
        
        # Get user profile
        profile_result = supabase.table("profiles")\
            .select("*")\
            .eq("user_id", req.user_id)\
            .single()\
            .execute()
        profile = profile_result.data
        
        # Run simulation
        result = simulate_cashflow(
            monthly_income=profile["monthly_income"],
            expenses=profile.get("expenses", {}),
            months=req.months,
            income_variation=req.income_variation,
            savings_goal=profile.get("savings_goal", 0)
        )
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/simulate/sip", methods=["POST"])
def simulate_sip_route():
    """Calculate SIP returns."""
    try:
        data = request.json
        req = SIPRequest(**data)
        
        result = calculate_sip(
            monthly_amount=req.monthly_amount,
            years=req.years,
            expected_return=req.expected_return
        )
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/simulate/goal", methods=["POST"])
def simulate_goal_route():
    """Calculate required SIP for a financial goal."""
    try:
        data = request.json
        goal_amount = data.get("goal_amount", 100000)
        years = data.get("years", 5)
        expected_return = data.get("expected_return", 12.0)
        
        result = suggest_sip_for_goal(
            goal_amount=goal_amount,
            years=years,
            expected_return=expected_return
        )
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400


# =====================
# MARKET DATA ROUTES
# =====================

@app.route("/market/funds/popular", methods=["GET"])
def get_popular_funds_route():
    """Get popular mutual funds."""
    from tools.finance_tools import get_popular_funds
    
    try:
        result = get_popular_funds.invoke("")
        return jsonify({"funds": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/market/funds/search", methods=["GET"])
def search_funds_route():
    """Search mutual funds."""
    from tools.finance_tools import search_mutual_funds
    
    query = request.args.get("q", "")
    try:
        result = search_mutual_funds.invoke(query)
        return jsonify({"funds": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/market/currency/usd-inr", methods=["GET"])
def get_usd_inr_route():
    """Get USD to INR exchange rate."""
    from tools.finance_tools import get_usd_inr_rate
    
    try:
        result = get_usd_inr_rate.invoke("")
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# =====================
# CONVERSATION HISTORY
# =====================

@app.route("/conversations/<user_id>", methods=["GET"])
def get_conversations(user_id: str):
    """Get conversation history for a user."""
    try:
        limit = request.args.get("limit", 20, type=int)
        
        result = supabase.table("conversations")\
            .select("*")\
            .eq("user_id", user_id)\
            .order("created_at", desc=True)\
            .limit(limit)\
            .execute()
        
        return jsonify({"conversations": result.data})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 400
    
    # Add after imports
from rag.vectorstore import init_knowledge_base

# Add before routes
print("🚀 Starting Financial Mentor API...")
try:
    init_knowledge_base()
except Exception as e:
    print(f"⚠️ KB init skipped: {e}")


# =====================
# RUN APP
# =====================

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)